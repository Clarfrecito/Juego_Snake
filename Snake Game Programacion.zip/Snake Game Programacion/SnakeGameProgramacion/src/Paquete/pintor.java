package Paquete;

import java.awt.Color;
import java.awt.Image;

/**
 *
 * @author PC01
 */
class pintor {

    static void drawImage(Image imagen, int i, int i0, int i1, int i2, Color BLACK, PanelSnake aThis) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static void drawImage(Image cabezaImage, int i, int i0, int i1, int i2, PanelSnake aThis) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
